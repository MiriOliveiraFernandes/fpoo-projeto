
	public class MAIN {

	public static void main(String[] args) {
		Menu objMenu= new Menu();
		objMenu.exibirMenu();
	
	}
	

}
